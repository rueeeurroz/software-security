# PL Fantasy — Batch 1 (security core, theme, Login, Register, shell, Home)

Stack: .NET 10, C#, Avalonia UI (MVVM), MySQL 8, VS Code.

## 1. Scaffold (skip what you already did)

```bash
mkdir PlFantasy && cd PlFantasy
dotnet new sln -n PlFantasy
dotnet new classlib -n PlFantasy.Core
dotnet new classlib -n PlFantasy.Data
dotnet new xunit    -n PlFantasy.Tests
dotnet new install Avalonia.Templates
dotnet new avalonia.mvvm -n PlFantasy.App
dotnet sln add PlFantasy.Core PlFantasy.Data PlFantasy.Tests PlFantasy.App

dotnet add PlFantasy.Core  package Konscious.Security.Cryptography.Argon2
dotnet add PlFantasy.Data  package MySqlConnector
dotnet add PlFantasy.Data  package Dapper
dotnet add PlFantasy.Data  reference PlFantasy.Core
dotnet add PlFantasy.App   reference PlFantasy.Core PlFantasy.Data
dotnet add PlFantasy.App   package Microsoft.Extensions.Configuration.Json
dotnet add PlFantasy.App   package Microsoft.Extensions.Configuration.UserSecrets
dotnet add PlFantasy.App   package Microsoft.Extensions.Configuration.EnvironmentVariables
dotnet add PlFantasy.Tests reference PlFantasy.Core PlFantasy.Data
```

Make sure every .csproj targets `net10.0`.

## 2. Copy this batch over the scaffold

Unzip into the solution folder (overwrite when asked), then delete the template leftovers:

- PlFantasy.Core/Class1.cs
- PlFantasy.Data/Class1.cs
- PlFantasy.Tests/UnitTest1.cs
- PlFantasy.App/ViewLocator.cs

## 3. Edit PlFantasy.App/PlFantasy.App.csproj

Inside the first `<PropertyGroup>` set (or add):

```xml
<AvaloniaUseCompiledBindingsByDefault>false</AvaloniaUseCompiledBindingsByDefault>
```

Add this item group so appsettings.json is copied next to the exe:

```xml
<ItemGroup>
  <None Update="appsettings.json" CopyToOutputDirectory="PreserveNewest" />
</ItemGroup>
```

## 4. Database

```bash
mysql -u root -p < sql/schema.sql
# edit the password in sql/create_app_user.sql first:
mysql -u root -p < sql/create_app_user.sql
```

## 5. Secrets (never committed)

```bash
dotnet user-secrets init --project PlFantasy.App

dotnet user-secrets set "ConnectionStrings:Default" "Server=localhost;Database=plfantasy;User ID=plfantasy_app;Password=YOUR_PASSWORD;SslMode=Preferred" --project PlFantasy.App
```

Generate the AES-256 key with a cryptographically secure generator:

- PowerShell: `[Convert]::ToBase64String([System.Security.Cryptography.RandomNumberGenerator]::GetBytes(32))`
- Linux/macOS: `openssl rand -base64 32`

```bash
dotnet user-secrets set "Crypto:Key" "PASTE_THE_BASE64_KEY" --project PlFantasy.App
```

## 6. Test and run

```bash
dotnet test
dotnet run --project PlFantasy.App
```

## Security map (for your write-up)

| Concern | Where |
|---|---|
| Password hashing (Argon2id, salt, constant-time compare) | Core/Security/PasswordHasher.cs |
| Password policy and strength meter | Core/Security/PasswordPolicy.cs |
| Input validation | Core/Security/InputValidator.cs |
| Authenticated encryption (AES-256-GCM, AAD) | Core/Security/CryptoService.cs |
| Session tokens (random, stored hashed) | Core/Security/SessionTokens.cs |
| Tamper-evident audit log (hash chain) | Core/Security/AuditChain.cs, Data/AuditLogRepository.cs |
| Login flow: lockout, no user enumeration, timing equalizer | Core/Services/AuthService.cs |
| Card validation and tokenization (no PAN/CVC stored) | Core/Security/CardValidator.cs, PaymentProviderSimulator.cs |
| Parameterized SQL | Data/*.cs |
| Least-privilege DB account, append-only audit table | sql/create_app_user.sql |
| Secrets out of source | App/Services/AppServices.cs |
