using Avalonia;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using PlFantasy.App.Services;
using PlFantasy.App.ViewModels;
using PlFantasy.App.Views;

namespace PlFantasy.App;

public partial class App : Application
{
    public override void Initialize() => AvaloniaXamlLoader.Load(this);

    public override void OnFrameworkInitializationCompleted()
    {
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var ok = AppServices.TryInit(out var error);
            desktop.MainWindow = new MainWindow { DataContext = new MainWindowViewModel(ok ? null : error) };
        }
        base.OnFrameworkInitializationCompleted();
    }
}
