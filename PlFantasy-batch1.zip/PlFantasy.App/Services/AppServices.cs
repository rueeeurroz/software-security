using System.Diagnostics;
using Microsoft.Extensions.Configuration;
using PlFantasy.Core.Abstractions;
using PlFantasy.Core.Security;
using PlFantasy.Core.Services;
using PlFantasy.Data;

namespace PlFantasy.App.Services;

/// <summary>Composition root. Secrets come from user-secrets or environment variables, never from source code.</summary>
public static class AppServices
{
    public static AuthService Auth { get; private set; } = null!;
    public static CryptoService Crypto { get; private set; } = null!;
    public static IAuditLog Audit { get; private set; } = null!;

    public static bool TryInit(out string? error)
    {
        try
        {
            var cfg = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("appsettings.json", optional: true)
                .AddUserSecrets(typeof(AppServices).Assembly, optional: true)
                .AddEnvironmentVariables("PLF_")      // e.g. PLF_ConnectionStrings__Default
                .Build();

            var connection = cfg["ConnectionStrings:Default"];
            var key = cfg["Crypto:Key"];
            if (string.IsNullOrWhiteSpace(connection) || string.IsNullOrWhiteSpace(key))
            {
                error = "Missing configuration. Set ConnectionStrings:Default and Crypto:Key with " +
                        "dotnet user-secrets (see README.md).";
                return false;
            }

            Crypto = CryptoService.FromBase64(key);
            var db = new Db(connection);
            var clock = TimeProvider.System;
            Audit = new AuditLogRepository(db, clock);
            Auth = new AuthService(new UserRepository(db), new SessionRepository(db), Audit, clock);
            error = null;
            return true;
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex);                         // details to the debug log only, never to the screen
            error = "Startup failed: the configuration is invalid.";
            return false;
        }
    }
}
