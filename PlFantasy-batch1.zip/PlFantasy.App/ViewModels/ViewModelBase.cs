using CommunityToolkit.Mvvm.ComponentModel;

namespace PlFantasy.App.ViewModels;

public abstract class ViewModelBase : ObservableObject { }
