using System.Collections.ObjectModel;
using Avalonia.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PlFantasy.Core.Models;

namespace PlFantasy.App.ViewModels;

public sealed record NewsItem(string Title, string When);

/// <summary>Layout-first version: the figures below are sample data, replaced by DB queries in a later batch.</summary>
public partial class HomeViewModel : ViewModelBase, IDisposable
{
    private readonly Action<string> _goTo;
    private readonly DispatcherTimer _timer;
    private readonly DateTime _deadline = NextDeadline();

    public string Greeting { get; }
    public string LeagueName => "PL Fantasy League";
    public string LeagueCode => "League code: 7F3K9";
    public string Rank => "124 / 512";
    public string NextFixtureHome => "Man City";
    public string NextFixtureAway => "Arsenal";
    public string NextFixtureWhen => "Sat, Oct 26 · 14:30";
    public string TopPlayerName => "Mohamed Salah";
    public string TopPlayerInfo => "MID · LIV · 82 pts";

    public ObservableCollection<NewsItem> News { get; } =
    [
        new("Salah hits 10 goals in 8 games", "2 hours ago"),
        new("Arsenal keep top spot with win", "4 hours ago"),
        new("Isak injury update", "6 hours ago"),
    ];

    [ObservableProperty] private string _days = "00";
    [ObservableProperty] private string _hours = "00";
    [ObservableProperty] private string _minutes = "00";

    public HomeViewModel(UserInfo user, Action<string> goTo)
    {
        _goTo = goTo;
        var h = DateTime.Now.Hour;
        var part = h < 12 ? "morning" : h < 18 ? "afternoon" : "evening";
        Greeting = $"Good {part}, {user.Username} 👋";

        Tick();
        _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        _timer.Tick += (_, _) => Tick();
        _timer.Start();
    }

    private static DateTime NextDeadline()
    {
        var now = DateTime.Now;
        int add = ((int)DayOfWeek.Saturday - (int)now.DayOfWeek + 7) % 7;
        var d = now.Date.AddDays(add).AddHours(14).AddMinutes(30);
        return d <= now ? d.AddDays(7) : d;
    }

    private void Tick()
    {
        var left = _deadline - DateTime.Now;
        if (left < TimeSpan.Zero) left = TimeSpan.Zero;
        Days = left.Days.ToString("00");
        Hours = left.Hours.ToString("00");
        Minutes = left.Minutes.ToString("00");
    }

    [RelayCommand] private void MakeTransfers() => _goTo("transfers");
    [RelayCommand] private void ViewLeague() => _goTo("leagues");
    [RelayCommand] private void ViewFixtures() => _goTo("fixtures");
    [RelayCommand] private void ViewPlayer() => _goTo("stats");

    public void Dispose() => _timer.Stop();
}
