using System.Collections.ObjectModel;
using System.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PlFantasy.App.Services;
using PlFantasy.Core.Models;

namespace PlFantasy.App.ViewModels;

public sealed record NavItem(string Key, string Title, string Glyph);

public partial class ShellViewModel : ViewModelBase
{
    private readonly INavigator _nav;
    private readonly string _token;

    public UserInfo User { get; }
    public string DisplayName => User.Username;
    public string Tier => User.IsPremium ? "Premium" : "Free plan";
    public string Initials => User.Username.Length >= 2 ? User.Username[..2].ToUpperInvariant() : User.Username.ToUpperInvariant();

    public ObservableCollection<NavItem> NavItems { get; } =
    [
        new("home", "Home", "⌂"),
        new("team", "My Team", "⚑"),
        new("transfers", "Transfers", "⇄"),
        new("leagues", "Leagues", "♛"),
        new("fixtures", "Fixtures", "▦"),
        new("stats", "Stats", "▤"),
        new("community", "Community", "☰"),
        new("store", "Store", "◫"),
    ];

    [ObservableProperty] private NavItem? _selected;
    [ObservableProperty] private ViewModelBase _page = null!;

    public ShellViewModel(INavigator nav, UserInfo user, string token)
    {
        _nav = nav; _token = token; User = user;
        Selected = NavItems[0];
    }

    partial void OnPageChanging(ViewModelBase value) => (Page as IDisposable)?.Dispose();

    partial void OnSelectedChanged(NavItem? value)
    {
        if (value is not null) Page = CreatePage(value);
    }

    private ViewModelBase CreatePage(NavItem item) => item.Key switch
    {
        "home" => new HomeViewModel(User, GoTo),
        _ => new PlaceholderViewModel(item.Title)
    };

    /// <summary>Lets any page jump to another section by key.</summary>
    public void GoTo(string key)
    {
        var item = NavItems.FirstOrDefault(n => n.Key == key);
        if (item is not null) Selected = item;
    }

    [RelayCommand]
    private void OpenProfile()
    {
        Selected = null;
        Page = new PlaceholderViewModel("Profile & Settings");
    }

    [RelayCommand]
    private async Task LogOutAsync()
    {
        (Page as IDisposable)?.Dispose();
        try { await AppServices.Auth.LogoutAsync(_token); }
        catch (Exception ex) { Debug.WriteLine(ex); }
        _nav.ShowLogin("You have been logged out.");
    }
}
