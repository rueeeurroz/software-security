using System.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PlFantasy.App.Services;

namespace PlFantasy.App.ViewModels;

public partial class LoginViewModel(INavigator nav) : ViewModelBase
{
    [ObservableProperty] private string _login = "";
    [ObservableProperty] private string _password = "";
    [ObservableProperty] private string? _error;
    [ObservableProperty] private string? _notice;
    [ObservableProperty] private bool _isBusy;

    [RelayCommand]
    private async Task LogInAsync()
    {
        if (IsBusy) return;
        IsBusy = true; Error = null; Notice = null;
        try
        {
            var result = await AppServices.Auth.LoginAsync(Login, Password);
            Password = "";                                   // drop the password from the UI state right away
            if (result.Success) nav.ShowShell(result.User!, result.SessionToken!);
            else Error = result.Error;
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex);
            Error = "Something went wrong. Please try again.";   // never show exception text to the user
        }
        finally { IsBusy = false; }
    }

    [RelayCommand] private void GoRegister() => nav.ShowRegister();
    [RelayCommand] private void Forgot() => Error = "Password reset is not part of this build yet.";
    [RelayCommand] private void Social() => Error = "Social sign-in is disabled in this course build.";
}
