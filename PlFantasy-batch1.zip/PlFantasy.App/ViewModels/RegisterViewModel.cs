using System.Diagnostics;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using PlFantasy.App.Services;
using PlFantasy.Core.Security;

namespace PlFantasy.App.ViewModels;

public partial class RegisterViewModel(INavigator nav) : ViewModelBase
{
    [ObservableProperty] private string _username = "";
    [ObservableProperty] private string _email = "";
    [ObservableProperty] private string _password = "";
    [ObservableProperty] private string _confirm = "";
    [ObservableProperty] private bool _agreeTerms;
    [ObservableProperty] private string? _error;
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private double _strength;
    [ObservableProperty] private string _strengthLabel = "";

    partial void OnPasswordChanged(string value)
    {
        var score = PasswordPolicy.Score(value);
        Strength = score * 25;
        StrengthLabel = value.Length == 0 ? "" : PasswordPolicy.Label(score);
    }

    [RelayCommand]
    private async Task CreateAccountAsync()
    {
        if (IsBusy) return;
        Error = null;
        if (!AgreeTerms) { Error = "Please accept the Terms of Service and Privacy Policy."; return; }

        IsBusy = true;
        try
        {
            var result = await AppServices.Auth.RegisterAsync(Username, Email, Password, Confirm);
            if (result.Success)
            {
                Password = ""; Confirm = "";
                nav.ShowLogin("Account created. You can log in now.");
            }
            else Error = result.Error;
        }
        catch (Exception ex)
        {
            Debug.WriteLine(ex);
            Error = "Something went wrong. Please try again.";
        }
        finally { IsBusy = false; }
    }

    [RelayCommand] private void GoLogin() => nav.ShowLogin();
}
