using CommunityToolkit.Mvvm.ComponentModel;
using PlFantasy.Core.Models;

namespace PlFantasy.App.ViewModels;

public interface INavigator
{
    void ShowLogin(string? notice = null);
    void ShowRegister();
    void ShowShell(UserInfo user, string sessionToken);
}

public sealed class StartupErrorViewModel(string message) : ViewModelBase
{
    public string Message { get; } = message;
}

public sealed class PlaceholderViewModel(string title) : ViewModelBase
{
    public string Title { get; } = title;
}

public partial class MainWindowViewModel : ViewModelBase, INavigator
{
    [ObservableProperty] private ViewModelBase? _current;

    public MainWindowViewModel(string? startupError = null)
    {
        if (startupError is not null) Current = new StartupErrorViewModel(startupError);
        else ShowLogin();
    }

    public void ShowLogin(string? notice = null) => Current = new LoginViewModel(this) { Notice = notice };
    public void ShowRegister() => Current = new RegisterViewModel(this);
    public void ShowShell(UserInfo user, string sessionToken) => Current = new ShellViewModel(this, user, sessionToken);
}
