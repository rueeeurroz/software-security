using Avalonia.Controls;

namespace PlFantasy.App.Views;

public partial class MainWindow : Window
{
    public MainWindow() => InitializeComponent();
}
