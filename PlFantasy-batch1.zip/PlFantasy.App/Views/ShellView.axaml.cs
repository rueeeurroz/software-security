using Avalonia.Controls;

namespace PlFantasy.App.Views;

public partial class ShellView : UserControl
{
    public ShellView() => InitializeComponent();
}
