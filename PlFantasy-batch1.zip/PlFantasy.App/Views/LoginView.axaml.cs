using Avalonia.Controls;

namespace PlFantasy.App.Views;

public partial class LoginView : UserControl
{
    public LoginView() => InitializeComponent();
}
