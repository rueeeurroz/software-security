using Avalonia.Controls;

namespace PlFantasy.App.Views;

public partial class HomeView : UserControl
{
    public HomeView() => InitializeComponent();
}
