using Avalonia.Controls;

namespace PlFantasy.App.Views;

public partial class PlaceholderView : UserControl
{
    public PlaceholderView() => InitializeComponent();
}
