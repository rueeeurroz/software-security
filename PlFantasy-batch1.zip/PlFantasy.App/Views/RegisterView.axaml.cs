using Avalonia.Controls;

namespace PlFantasy.App.Views;

public partial class RegisterView : UserControl
{
    public RegisterView() => InitializeComponent();
}
