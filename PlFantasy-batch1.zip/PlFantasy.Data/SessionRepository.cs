using Dapper;
using PlFantasy.Core.Abstractions;

namespace PlFantasy.Data;

public sealed class SessionRepository(Db db) : ISessionRepository
{
    public async Task CreateAsync(long userId, byte[] tokenHash, DateTime expiresAtUtc, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        await c.ExecuteAsync(new CommandDefinition(
            "INSERT INTO sessions (user_id, token_hash, expires_at) VALUES (@userId, @tokenHash, @expiresAtUtc)",
            new { userId, tokenHash, expiresAtUtc }, cancellationToken: ct));
    }

    public async Task<long?> FindUserIdAsync(byte[] tokenHash, DateTime nowUtc, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        return await c.QuerySingleOrDefaultAsync<long?>(new CommandDefinition(
            "SELECT user_id FROM sessions WHERE token_hash = @tokenHash AND expires_at > @nowUtc",
            new { tokenHash, nowUtc }, cancellationToken: ct));
    }

    public async Task DeleteAsync(byte[] tokenHash, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        await c.ExecuteAsync(new CommandDefinition(
            "DELETE FROM sessions WHERE token_hash = @tokenHash", new { tokenHash }, cancellationToken: ct));
    }
}
