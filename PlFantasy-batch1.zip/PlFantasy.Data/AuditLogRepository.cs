using Dapper;
using PlFantasy.Core.Abstractions;
using PlFantasy.Core.Models;
using PlFantasy.Core.Security;

namespace PlFantasy.Data;

/// <summary>Append-only. The DB user for the app is not even granted UPDATE or DELETE on audit_log.</summary>
public sealed class AuditLogRepository(Db db, TimeProvider clock) : IAuditLog
{
    public async Task AppendAsync(long? userId, string eventName, string? detail = null)
    {
        await using var conn = await db.OpenAsync();
        await using var tx = await conn.BeginTransactionAsync();

        var prev = await conn.QuerySingleOrDefaultAsync<byte[]>(
            "SELECT entry_hash FROM audit_log ORDER BY id DESC LIMIT 1 FOR UPDATE", transaction: tx)
            ?? AuditChain.Genesis;

        var t = clock.GetUtcNow().UtcDateTime;
        var now = new DateTime(t.Ticks - t.Ticks % TimeSpan.TicksPerSecond, DateTimeKind.Utc);
        var hash = AuditChain.Compute(prev, userId, eventName, detail, now);

        await conn.ExecuteAsync(
            @"INSERT INTO audit_log (user_id, event, detail, prev_hash, entry_hash, created_at)
              VALUES (@userId, @eventName, @detail, @prev, @hash, @now)",
            new { userId, eventName, detail, prev, hash, now }, tx);

        await tx.CommitAsync();
    }

    public async Task<bool> VerifyChainAsync()
    {
        await using var conn = await db.OpenAsync();
        var rows = await conn.QueryAsync<AuditEntry>("SELECT * FROM audit_log ORDER BY id ASC");
        return AuditChain.Verify(rows);
    }
}
