using Dapper;
using MySqlConnector;
using PlFantasy.Core.Abstractions;
using PlFantasy.Core.Models;

namespace PlFantasy.Data;

/// <summary>All SQL is parameterized. No string concatenation of user input, ever.</summary>
public sealed class UserRepository(Db db) : IUserRepository
{
    public async Task<UserRecord?> FindByLoginAsync(string normalizedKey, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        return await c.QuerySingleOrDefaultAsync<UserRecord>(new CommandDefinition(
            "SELECT * FROM users WHERE username_norm = @key OR email = @key LIMIT 1",
            new { key = normalizedKey }, cancellationToken: ct));
    }

    public async Task<UserRecord?> GetByIdAsync(long id, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        return await c.QuerySingleOrDefaultAsync<UserRecord>(new CommandDefinition(
            "SELECT * FROM users WHERE id = @id", new { id }, cancellationToken: ct));
    }

    public async Task<long> CreateAsync(UserRecord u, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        try
        {
            return await c.ExecuteScalarAsync<long>(new CommandDefinition(
                @"INSERT INTO users (username, username_norm, email, password_hash, password_salt, kdf_params)
                  VALUES (@Username, @UsernameNorm, @Email, @PasswordHash, @PasswordSalt, @KdfParams);
                  SELECT LAST_INSERT_ID();", u, cancellationToken: ct));
        }
        catch (MySqlException ex) when (ex.ErrorCode == MySqlErrorCode.DuplicateKeyEntry)
        {
            throw new DuplicateUserException();
        }
    }

    public async Task RegisterFailureAsync(long id, int attempts, DateTime? lockedUntilUtc, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        await c.ExecuteAsync(new CommandDefinition(
            "UPDATE users SET failed_attempts = @attempts, locked_until = @lockedUntilUtc WHERE id = @id",
            new { id, attempts, lockedUntilUtc }, cancellationToken: ct));
    }

    public async Task ResetFailuresAsync(long id, CancellationToken ct = default)
    {
        await using var c = await db.OpenAsync(ct);
        await c.ExecuteAsync(new CommandDefinition(
            "UPDATE users SET failed_attempts = 0, locked_until = NULL WHERE id = @id",
            new { id }, cancellationToken: ct));
    }
}
