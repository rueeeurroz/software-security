using Dapper;
using MySqlConnector;

namespace PlFantasy.Data;

public sealed class Db(string connectionString)
{
    static Db() => DefaultTypeMap.MatchNamesWithUnderscores = true; // password_hash -> PasswordHash

    public async Task<MySqlConnection> OpenAsync(CancellationToken ct = default)
    {
        var conn = new MySqlConnection(connectionString);
        await conn.OpenAsync(ct);
        return conn;
    }
}
