-- Run as a MySQL admin. Change the password first, and keep it out of source control.
CREATE USER 'plfantasy_app'@'localhost' IDENTIFIED BY 'CHANGE_ME_long_random_password';

-- Least privilege: only what the app needs, per table.
GRANT SELECT, INSERT, UPDATE         ON plfantasy.users           TO 'plfantasy_app'@'localhost';
GRANT SELECT, INSERT, DELETE         ON plfantasy.sessions        TO 'plfantasy_app'@'localhost';
GRANT SELECT, INSERT, DELETE         ON plfantasy.payment_methods TO 'plfantasy_app'@'localhost';
GRANT SELECT, INSERT                 ON plfantasy.audit_log       TO 'plfantasy_app'@'localhost';  -- append-only

FLUSH PRIVILEGES;
