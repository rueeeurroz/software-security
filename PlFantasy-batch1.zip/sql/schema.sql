CREATE DATABASE IF NOT EXISTS plfantasy CHARACTER SET utf8mb4;
USE plfantasy;

CREATE TABLE users (
  id               BIGINT AUTO_INCREMENT PRIMARY KEY,
  username         VARCHAR(30)   NOT NULL,
  username_norm    VARCHAR(30)   NOT NULL UNIQUE,   -- lowercase, for uniqueness and login
  email            VARCHAR(255)  NOT NULL UNIQUE,   -- stored lowercase
  password_hash    VARBINARY(64) NOT NULL,          -- Argon2id output
  password_salt    VARBINARY(32) NOT NULL,
  kdf_params       VARCHAR(64)   NOT NULL,          -- e.g. argon2id;m=65536;t=3;p=2;v=1
  failed_attempts  INT           NOT NULL DEFAULT 0,
  locked_until     DATETIME      NULL,
  is_premium       BOOLEAN       NOT NULL DEFAULT FALSE,
  created_at       DATETIME      NOT NULL DEFAULT (UTC_TIMESTAMP())
);

CREATE TABLE sessions (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT     NOT NULL,
  token_hash  BINARY(32) NOT NULL UNIQUE,           -- SHA-256 of the random token
  created_at  DATETIME   NOT NULL DEFAULT (UTC_TIMESTAMP()),
  expires_at  DATETIME   NOT NULL,
  INDEX idx_sessions_expires (expires_at),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE payment_methods (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT        NOT NULL,
  brand       VARCHAR(20)   NOT NULL,
  last4       CHAR(4)       NOT NULL,
  exp_month   SMALLINT      NOT NULL,
  exp_year    SMALLINT      NOT NULL,
  token_enc   VARBINARY(256) NOT NULL,              -- AES-256-GCM blob: nonce|tag|ciphertext
  created_at  DATETIME      NOT NULL DEFAULT (UTC_TIMESTAMP()),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE audit_log (
  id          BIGINT AUTO_INCREMENT PRIMARY KEY,
  user_id     BIGINT        NULL,
  event       VARCHAR(50)   NOT NULL,
  detail      VARCHAR(500)  NULL,
  prev_hash   BINARY(32)    NOT NULL,
  entry_hash  BINARY(32)    NOT NULL,
  created_at  DATETIME      NOT NULL
);
