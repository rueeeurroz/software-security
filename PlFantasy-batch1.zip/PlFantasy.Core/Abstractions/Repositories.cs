using PlFantasy.Core.Models;

namespace PlFantasy.Core.Abstractions;

public interface IUserRepository
{
    Task<UserRecord?> FindByLoginAsync(string normalizedKey, CancellationToken ct = default);
    Task<UserRecord?> GetByIdAsync(long id, CancellationToken ct = default);
    Task<long> CreateAsync(UserRecord user, CancellationToken ct = default);
    Task RegisterFailureAsync(long id, int attempts, DateTime? lockedUntilUtc, CancellationToken ct = default);
    Task ResetFailuresAsync(long id, CancellationToken ct = default);
}

public interface ISessionRepository
{
    Task CreateAsync(long userId, byte[] tokenHash, DateTime expiresAtUtc, CancellationToken ct = default);
    Task<long?> FindUserIdAsync(byte[] tokenHash, DateTime nowUtc, CancellationToken ct = default);
    Task DeleteAsync(byte[] tokenHash, CancellationToken ct = default);
}

public interface IAuditLog
{
    Task AppendAsync(long? userId, string eventName, string? detail = null);
    Task<bool> VerifyChainAsync();
}
