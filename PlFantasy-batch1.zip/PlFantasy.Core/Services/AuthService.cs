using PlFantasy.Core.Abstractions;
using PlFantasy.Core.Models;
using PlFantasy.Core.Security;

namespace PlFantasy.Core.Services;

public sealed record AuthResult(bool Success, string? Error = null, UserInfo? User = null, string? SessionToken = null);

public sealed class AuthService(IUserRepository users, ISessionRepository sessions, IAuditLog audit, TimeProvider clock)
{
    public const int MaxFailedAttempts = 5;
    public static readonly TimeSpan LockoutDuration = TimeSpan.FromMinutes(15);
    public static readonly TimeSpan SessionLifetime = TimeSpan.FromHours(8);

    // One message for: unknown user, wrong password, locked account. Prevents user enumeration.
    public const string GenericLoginError = "Invalid credentials, or the account is temporarily locked.";

    // Verified against when the user doesn't exist, so "unknown user" takes as long as "wrong password".
    private static readonly HashResult Dummy = PasswordHasher.Hash("timing-equalizer-not-a-real-password");

    private DateTime Now => clock.GetUtcNow().UtcDateTime;
    private static AuthResult Fail(string error) => new(false, error);
    private static UserInfo ToInfo(UserRecord u) => new(u.Id, u.Username, u.Email, u.IsPremium);

    public async Task<AuthResult> RegisterAsync(string username, string email, string password, string confirm,
        CancellationToken ct = default)
    {
        username = (username ?? "").Trim();
        email = (email ?? "").Trim();
        password ??= "";

        if (!InputValidator.IsValidUsername(username))
            return Fail("Username must be 3-30 characters: letters, numbers or underscore.");
        if (!InputValidator.IsValidEmail(email)) return Fail("Enter a valid email address.");
        if (password != confirm) return Fail("Passwords do not match.");
        var problems = PasswordPolicy.Check(password, username);
        if (problems.Count > 0) return Fail(problems[0]);

        var hr = await Task.Run(() => PasswordHasher.Hash(password), ct);
        var record = new UserRecord
        {
            Username = username,
            UsernameNorm = username.ToLowerInvariant(),
            Email = email.ToLowerInvariant(),
            PasswordHash = hr.Hash,
            PasswordSalt = hr.Salt,
            KdfParams = hr.Params
        };

        try { record.Id = await users.CreateAsync(record, ct); }
        catch (DuplicateUserException)
        {
            await audit.AppendAsync(null, "REGISTER_DUPLICATE");
            return Fail("That username or email is already in use.");
        }

        await audit.AppendAsync(record.Id, "REGISTER_OK");
        return new AuthResult(true, User: ToInfo(record));
    }

    public async Task<AuthResult> LoginAsync(string login, string password, CancellationToken ct = default)
    {
        var key = (login ?? "").Trim().ToLowerInvariant();
        if (key.Length == 0 || string.IsNullOrEmpty(password) || password.Length > PasswordPolicy.MaxLength)
            return Fail(GenericLoginError);

        var user = await users.FindByLoginAsync(key, ct);

        if (user is null)
        {
            await Task.Run(() => PasswordHasher.Verify(password, Dummy.Salt, Dummy.Hash), ct);
            // Never log what was typed: people sometimes paste a password into the username box.
            await audit.AppendAsync(null, "LOGIN_FAIL", "unknown user");
            return Fail(GenericLoginError);
        }

        var now = Now;
        if (user.LockedUntil is { } until && until > now)
        {
            await audit.AppendAsync(user.Id, "LOGIN_BLOCKED", "account locked");
            return Fail(GenericLoginError);
        }

        var ok = await Task.Run(() => PasswordHasher.Verify(password, user.PasswordSalt, user.PasswordHash), ct);
        if (!ok)
        {
            var attempts = user.FailedAttempts + 1;
            if (attempts >= MaxFailedAttempts)
            {
                await users.RegisterFailureAsync(user.Id, 0, now + LockoutDuration, ct);
                await audit.AppendAsync(user.Id, "ACCOUNT_LOCKED", $"{MaxFailedAttempts} failed attempts");
            }
            else
            {
                await users.RegisterFailureAsync(user.Id, attempts, null, ct);
                await audit.AppendAsync(user.Id, "LOGIN_FAIL", "bad password");
            }
            return Fail(GenericLoginError);
        }

        await users.ResetFailuresAsync(user.Id, ct);
        var (token, hash) = SessionTokens.Create();
        await sessions.CreateAsync(user.Id, hash, now + SessionLifetime, ct);
        await audit.AppendAsync(user.Id, "LOGIN_OK");
        return new AuthResult(true, User: ToInfo(user), SessionToken: token);
    }

    public async Task<UserInfo?> ValidateSessionAsync(string token, CancellationToken ct = default)
    {
        var uid = await sessions.FindUserIdAsync(SessionTokens.Hash(token), Now, ct);
        if (uid is null) return null;
        var u = await users.GetByIdAsync(uid.Value, ct);
        return u is null ? null : ToInfo(u);
    }

    public async Task LogoutAsync(string token, CancellationToken ct = default)
    {
        var hash = SessionTokens.Hash(token);
        var uid = await sessions.FindUserIdAsync(hash, Now, ct);
        await sessions.DeleteAsync(hash, ct);
        await audit.AppendAsync(uid, "LOGOUT");
    }
}
