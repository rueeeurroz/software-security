using System.Buffers.Text;
using System.Security.Cryptography;
using System.Text;

namespace PlFantasy.Core.Security;

/// <summary>256-bit random session tokens. Only the SHA-256 of a token is stored server-side.</summary>
public static class SessionTokens
{
    public static (string Token, byte[] Hash) Create()
    {
        var token = Base64Url.EncodeToString(RandomNumberGenerator.GetBytes(32));
        return (token, Hash(token));
    }

    public static byte[] Hash(string token) => SHA256.HashData(Encoding.UTF8.GetBytes(token));
}
