using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using PlFantasy.Core.Models;

namespace PlFantasy.Core.Security;

/// <summary>Tamper-evident log: every entry hash covers the previous entry's hash (a simple hash chain).</summary>
public static class AuditChain
{
    public static readonly byte[] Genesis = new byte[32];

    public static byte[] Compute(byte[] prevHash, long? userId, string ev, string? detail, DateTime createdUtc)
    {
        // Second precision, because MySQL DATETIME(0) drops fractions.
        var ts = createdUtc.ToString("yyyy-MM-dd'T'HH:mm:ss", CultureInfo.InvariantCulture);
        var payload = Encoding.UTF8.GetBytes($"{userId?.ToString() ?? "-"}|{ev}|{detail ?? ""}|{ts}");
        return SHA256.HashData([.. prevHash, .. payload]);
    }

    public static bool Verify(IEnumerable<AuditEntry> entriesInOrder)
    {
        var prev = Genesis;
        foreach (var e in entriesInOrder)
        {
            if (!CryptographicOperations.FixedTimeEquals(e.PrevHash, prev)) return false;
            var expected = Compute(e.PrevHash, e.UserId, e.Event, e.Detail, e.CreatedAt);
            if (!CryptographicOperations.FixedTimeEquals(expected, e.EntryHash)) return false;
            prev = e.EntryHash;
        }
        return true;
    }
}
