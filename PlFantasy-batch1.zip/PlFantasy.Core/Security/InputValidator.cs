using System.Text.RegularExpressions;

namespace PlFantasy.Core.Security;

public static class InputValidator
{
    // No '@' allowed in usernames, so a username can never collide with an email at login.
    private static readonly Regex UsernameRx = new(@"^[A-Za-z0-9_]{3,30}$", RegexOptions.Compiled);
    private static readonly Regex EmailRx = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);

    public static bool IsValidUsername(string? s) => s is not null && UsernameRx.IsMatch(s);
    public static bool IsValidEmail(string? s) => s is not null && s.Length <= 255 && EmailRx.IsMatch(s);
}
