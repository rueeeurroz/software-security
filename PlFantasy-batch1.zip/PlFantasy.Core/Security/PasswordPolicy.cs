namespace PlFantasy.Core.Security;

public static class PasswordPolicy
{
    public const int MinLength = 10;
    public const int MaxLength = 128; // cap input size so huge passwords can't be used to burn CPU/memory

    private static readonly HashSet<string> Common = new(StringComparer.OrdinalIgnoreCase)
    {
        "password", "password1", "password123", "1234567890", "qwertyuiop", "letmein123",
        "iloveyou12", "admin12345", "welcome123", "football123", "premierleague"
    };

    public static List<string> Check(string? password, string? username = null)
    {
        var problems = new List<string>();
        password ??= "";
        if (password.Length < MinLength) problems.Add($"Password must be at least {MinLength} characters.");
        if (password.Length > MaxLength) problems.Add($"Password must be at most {MaxLength} characters.");
        if (!password.Any(char.IsUpper)) problems.Add("Add at least one uppercase letter.");
        if (!password.Any(char.IsLower)) problems.Add("Add at least one lowercase letter.");
        if (!password.Any(char.IsDigit)) problems.Add("Add at least one number.");
        if (!password.Any(c => !char.IsLetterOrDigit(c))) problems.Add("Add at least one symbol.");
        if (Common.Contains(password)) problems.Add("That password is too common.");
        if (!string.IsNullOrEmpty(username) && username.Length >= 3 &&
            password.Contains(username, StringComparison.OrdinalIgnoreCase))
            problems.Add("Password must not contain your username.");
        return problems;
    }

    /// <summary>0 (too weak) to 4 (strong). Used by the live strength meter.</summary>
    public static int Score(string? p)
    {
        if (string.IsNullOrEmpty(p) || Common.Contains(p)) return 0;
        int classes = (p.Any(char.IsUpper) ? 1 : 0) + (p.Any(char.IsLower) ? 1 : 0) +
                      (p.Any(char.IsDigit) ? 1 : 0) + (p.Any(c => !char.IsLetterOrDigit(c)) ? 1 : 0);
        int s = 0;
        if (p.Length >= MinLength) s++;
        if (p.Length >= 14) s++;
        if (classes >= 3) s++;
        if (classes == 4) s++;
        return s;
    }

    public static string Label(int score) => score switch
    {
        0 => "Too weak", 1 => "Weak", 2 => "Fair", 3 => "Good", _ => "Strong"
    };
}
