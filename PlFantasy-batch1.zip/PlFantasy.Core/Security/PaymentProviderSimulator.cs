using System.Buffers.Text;
using System.Security.Cryptography;

namespace PlFantasy.Core.Security;

public sealed record TokenizedCard(string Brand, string Last4, int ExpMonth, int ExpYear, string ProviderToken);

/// <summary>
/// Stands in for a payment provider (Stripe, Adyen...). It validates card input, then returns ONLY a token
/// and display data. The full card number and CVC are never stored, logged or returned.
/// In a real system the provider's hosted fields mean the card number never touches your server at all.
/// </summary>
public static class PaymentProviderSimulator
{
    public static bool TryTokenize(string cardNumber, string expiry, string cvc, DateTime nowUtc,
        out TokenizedCard? card, out string? error)
    {
        card = null; error = null;
        var pan = CardValidator.Digits(cardNumber);
        if (!CardValidator.Luhn(pan)) { error = "Card number is invalid."; return false; }
        if (!CardValidator.TryParseExpiry(expiry, out var m, out var y) || !CardValidator.IsValidExpiry(m, y, nowUtc))
        { error = "Card expiry is invalid or the card has expired."; return false; }
        var brand = CardValidator.Brand(pan);
        if (!CardValidator.IsValidCvc(cvc, brand)) { error = "CVC is invalid."; return false; }

        var token = "tok_" + Base64Url.EncodeToString(RandomNumberGenerator.GetBytes(18));
        card = new TokenizedCard(brand, pan[^4..], m, y, token);
        return true;
    }
}
