namespace PlFantasy.Core.Security;

public static class CardValidator
{
    public static string Digits(string? s) => new((s ?? "").Where(char.IsAsciiDigit).ToArray());

    public static bool Luhn(string digits)
    {
        if (digits.Length is < 12 or > 19 || !digits.All(char.IsAsciiDigit)) return false;
        int sum = 0; bool dbl = false;
        for (int i = digits.Length - 1; i >= 0; i--)
        {
            int n = digits[i] - '0';
            if (dbl) { n *= 2; if (n > 9) n -= 9; }
            sum += n; dbl = !dbl;
        }
        return sum % 10 == 0;
    }

    public static string Brand(string digits)
    {
        if (digits.Length < 4) return "Card";
        if (digits[0] == '4') return "Visa";
        int p2 = int.Parse(digits[..2]), p4 = int.Parse(digits[..4]);
        if (p2 is >= 51 and <= 55 || p4 is >= 2221 and <= 2720) return "Mastercard";
        if (p2 is 34 or 37) return "Amex";
        return "Card";
    }

    /// <summary>Accepts "MM / YY", "MM/YY" or "MMYY".</summary>
    public static bool TryParseExpiry(string? text, out int month, out int year)
    {
        month = 0; year = 0;
        var d = Digits(text);
        if (d.Length != 4) return false;
        month = int.Parse(d[..2]);
        year = 2000 + int.Parse(d[2..]);
        return true;
    }

    public static bool IsValidExpiry(int month, int year, DateTime nowUtc)
    {
        if (month is < 1 or > 12 || year > nowUtc.Year + 20) return false;
        return new DateTime(year, month, 1).AddMonths(1) > nowUtc; // valid through the end of the month
    }

    public static bool IsValidCvc(string? cvc, string brand)
    {
        var d = Digits(cvc);
        return d.Length == (brand == "Amex" ? 4 : 3) && d == cvc;
    }
}
