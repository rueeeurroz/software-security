using System.Security.Cryptography;
using System.Text;

namespace PlFantasy.Core.Security;

/// <summary>
/// AES-256-GCM authenticated encryption. Blob layout: nonce(12) | tag(16) | ciphertext.
/// Optional associated data (AAD) binds a ciphertext to its owner, e.g. the user id.
/// </summary>
public sealed class CryptoService
{
    private const int NonceLen = 12, TagLen = 16;
    private readonly byte[] _key;

    public CryptoService(byte[] key)
    {
        if (key.Length != 32) throw new ArgumentException("Key must be 32 bytes (AES-256).");
        _key = (byte[])key.Clone();
    }

    public static CryptoService FromBase64(string base64) => new(Convert.FromBase64String(base64));
    public static string GenerateKeyBase64() => Convert.ToBase64String(RandomNumberGenerator.GetBytes(32));

    public byte[] Encrypt(byte[] plaintext, byte[]? aad = null)
    {
        var nonce = RandomNumberGenerator.GetBytes(NonceLen); // fresh random nonce every call
        var cipher = new byte[plaintext.Length];
        var tag = new byte[TagLen];
        using var aes = new AesGcm(_key, TagLen);
        aes.Encrypt(nonce, plaintext, cipher, tag, aad);
        return [.. nonce, .. tag, .. cipher];
    }

    public byte[] Decrypt(byte[] blob, byte[]? aad = null)
    {
        if (blob.Length < NonceLen + TagLen) throw new CryptographicException("Invalid ciphertext.");
        var nonce = blob.AsSpan(0, NonceLen);
        var tag = blob.AsSpan(NonceLen, TagLen);
        var cipher = blob.AsSpan(NonceLen + TagLen);
        var plain = new byte[cipher.Length];
        using var aes = new AesGcm(_key, TagLen);
        aes.Decrypt(nonce, cipher, tag, plain, aad); // throws if tampered or wrong AAD/key
        return plain;
    }

    public byte[] EncryptString(string s, byte[]? aad = null) => Encrypt(Encoding.UTF8.GetBytes(s), aad);
    public string DecryptString(byte[] blob, byte[]? aad = null) => Encoding.UTF8.GetString(Decrypt(blob, aad));
}
