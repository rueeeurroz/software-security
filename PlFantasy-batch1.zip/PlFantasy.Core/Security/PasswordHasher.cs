using System.Security.Cryptography;
using System.Text;
using Konscious.Security.Cryptography;

namespace PlFantasy.Core.Security;

public sealed record HashResult(byte[] Hash, byte[] Salt, string Params);

/// <summary>Argon2id password hashing with a per-user random salt and constant-time verification.</summary>
public static class PasswordHasher
{
    private const int MemoryKb = 65536, Iterations = 3, Parallelism = 2, HashLen = 32, SaltLen = 16;
    public const string CurrentParams = "argon2id;m=65536;t=3;p=2;v=1";

    public static HashResult Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(SaltLen);
        return new HashResult(Compute(password, salt), salt, CurrentParams);
    }

    public static bool Verify(string password, byte[] salt, byte[] expectedHash)
    {
        var actual = Compute(password, salt);
        return CryptographicOperations.FixedTimeEquals(actual, expectedHash);
    }

    private static byte[] Compute(string password, byte[] salt)
    {
        using var argon = new Argon2id(Encoding.UTF8.GetBytes(password))
        {
            Salt = salt,
            MemorySize = MemoryKb,
            Iterations = Iterations,
            DegreeOfParallelism = Parallelism
        };
        return argon.GetBytes(HashLen);
    }
}
