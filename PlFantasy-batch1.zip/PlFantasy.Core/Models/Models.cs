namespace PlFantasy.Core.Models;

public sealed class UserRecord
{
    public long Id { get; set; }
    public string Username { get; set; } = "";
    public string UsernameNorm { get; set; } = "";
    public string Email { get; set; } = "";
    public byte[] PasswordHash { get; set; } = [];
    public byte[] PasswordSalt { get; set; } = [];
    public string KdfParams { get; set; } = "";
    public int FailedAttempts { get; set; }
    public DateTime? LockedUntil { get; set; }
    public bool IsPremium { get; set; }
    public DateTime CreatedAt { get; set; }
}

public sealed record UserInfo(long Id, string Username, string Email, bool IsPremium);

public sealed class AuditEntry
{
    public long Id { get; set; }
    public long? UserId { get; set; }
    public string Event { get; set; } = "";
    public string? Detail { get; set; }
    public byte[] PrevHash { get; set; } = [];
    public byte[] EntryHash { get; set; } = [];
    public DateTime CreatedAt { get; set; }
}

public sealed class DuplicateUserException() : Exception("Duplicate user.");
