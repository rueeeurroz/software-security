using System.Security.Cryptography;
using PlFantasy.Core.Models;
using PlFantasy.Core.Security;
using Xunit;

namespace PlFantasy.Tests;

public class PasswordHasherTests
{
    [Fact]
    public void Same_password_gets_different_salt_and_hash()
    {
        var a = PasswordHasher.Hash("Str0ng!Passw0rd");
        var b = PasswordHasher.Hash("Str0ng!Passw0rd");
        Assert.NotEqual(a.Salt, b.Salt);
        Assert.NotEqual(a.Hash, b.Hash);
    }

    [Fact]
    public void Verify_accepts_right_and_rejects_wrong_password()
    {
        var h = PasswordHasher.Hash("Str0ng!Passw0rd");
        Assert.True(PasswordHasher.Verify("Str0ng!Passw0rd", h.Salt, h.Hash));
        Assert.False(PasswordHasher.Verify("Str0ng!Passw0re", h.Salt, h.Hash));
    }
}

public class PasswordPolicyTests
{
    [Theory]
    [InlineData("short1!A")]
    [InlineData("alllowercase1!")]
    [InlineData("ALLUPPERCASE1!")]
    [InlineData("NoDigitsHere!!")]
    [InlineData("NoSymbols12345A")]
    public void Rejects_weak_passwords(string pw) => Assert.NotEmpty(PasswordPolicy.Check(pw));

    [Fact] public void Accepts_strong_password() => Assert.Empty(PasswordPolicy.Check("Str0ng!Passw0rd", "rama"));
    [Fact] public void Rejects_password_containing_username() =>
        Assert.NotEmpty(PasswordPolicy.Check("Rama_mousa#2026x", "rama_mousa"));
    [Fact] public void Score_increases_with_strength() =>
        Assert.True(PasswordPolicy.Score("Str0ng!Passw0rd") > PasswordPolicy.Score("abc"));
}

public class CryptoServiceTests
{
    private static CryptoService NewService() => CryptoService.FromBase64(CryptoService.GenerateKeyBase64());

    [Fact]
    public void Round_trip_works()
    {
        var c = NewService();
        Assert.Equal("tok_abc", c.DecryptString(c.EncryptString("tok_abc")));
    }

    [Fact]
    public void Same_plaintext_encrypts_differently_each_time()
    {
        var c = NewService();
        Assert.NotEqual(c.EncryptString("x"), c.EncryptString("x"));
    }

    [Fact]
    public void Tampering_is_detected()
    {
        var c = NewService();
        var blob = c.EncryptString("tok_abc");
        blob[^1] ^= 0x01;
        Assert.ThrowsAny<CryptographicException>(() => c.DecryptString(blob));
    }

    [Fact]
    public void Wrong_associated_data_is_rejected()
    {
        var c = NewService();
        var blob = c.EncryptString("tok_abc", [1, 2, 3]);
        Assert.ThrowsAny<CryptographicException>(() => c.DecryptString(blob, [9, 9, 9]));
    }
}

public class CardValidatorTests
{
    [Fact] public void Luhn_accepts_valid_test_card() => Assert.True(CardValidator.Luhn("4242424242424242"));
    [Fact] public void Luhn_rejects_bad_checksum() => Assert.False(CardValidator.Luhn("4242424242424241"));
    [Fact] public void Detects_brands()
    {
        Assert.Equal("Visa", CardValidator.Brand("4242424242424242"));
        Assert.Equal("Mastercard", CardValidator.Brand("5555555555554444"));
        Assert.Equal("Amex", CardValidator.Brand("378282246310005"));
    }

    [Fact]
    public void Expired_card_is_rejected()
    {
        var now = new DateTime(2026, 10, 27, 0, 0, 0, DateTimeKind.Utc);
        Assert.False(CardValidator.IsValidExpiry(9, 2026, now));
        Assert.True(CardValidator.IsValidExpiry(10, 2026, now));
    }

    [Fact]
    public void Tokenizer_returns_only_last4_and_token()
    {
        var now = new DateTime(2026, 10, 27, 0, 0, 0, DateTimeKind.Utc);
        Assert.True(PaymentProviderSimulator.TryTokenize("4242 4242 4242 4242", "12 / 28", "123", now, out var card, out _));
        Assert.Equal("4242", card!.Last4);
        Assert.StartsWith("tok_", card.ProviderToken);
        Assert.DoesNotContain("4242424242424242", card.ProviderToken);
    }
}

public class AuditChainTests
{
    private static List<AuditEntry> Build()
    {
        var list = new List<AuditEntry>();
        var prev = AuditChain.Genesis;
        var t = new DateTime(2026, 10, 27, 12, 0, 0, DateTimeKind.Utc);
        foreach (var ev in new[] { "LOGIN_OK", "LOGIN_FAIL", "LOGOUT" })
        {
            var hash = AuditChain.Compute(prev, 1, ev, null, t);
            list.Add(new AuditEntry { UserId = 1, Event = ev, PrevHash = prev, EntryHash = hash, CreatedAt = t });
            prev = hash; t = t.AddSeconds(5);
        }
        return list;
    }

    [Fact] public void Intact_chain_verifies() => Assert.True(AuditChain.Verify(Build()));

    [Fact]
    public void Edited_entry_breaks_chain()
    {
        var chain = Build();
        chain[1].Event = "LOGIN_OK";
        Assert.False(AuditChain.Verify(chain));
    }

    [Fact]
    public void Deleted_entry_breaks_chain()
    {
        var chain = Build();
        chain.RemoveAt(1);
        Assert.False(AuditChain.Verify(chain));
    }
}
