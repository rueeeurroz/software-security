using PlFantasy.Core.Abstractions;
using PlFantasy.Core.Models;
using PlFantasy.Core.Services;
using Xunit;

namespace PlFantasy.Tests;

sealed class TestClock : TimeProvider
{
    public DateTimeOffset Now = new(2026, 10, 27, 12, 0, 0, TimeSpan.Zero);
    public override DateTimeOffset GetUtcNow() => Now;
}

sealed class FakeUsers : IUserRepository
{
    public readonly List<UserRecord> Rows = [];
    private long _id;
    public Task<UserRecord?> FindByLoginAsync(string k, CancellationToken ct = default) =>
        Task.FromResult(Rows.FirstOrDefault(u => u.UsernameNorm == k || u.Email == k));
    public Task<UserRecord?> GetByIdAsync(long id, CancellationToken ct = default) =>
        Task.FromResult(Rows.FirstOrDefault(u => u.Id == id));
    public Task<long> CreateAsync(UserRecord u, CancellationToken ct = default)
    {
        if (Rows.Any(r => r.UsernameNorm == u.UsernameNorm || r.Email == u.Email)) throw new DuplicateUserException();
        u.Id = ++_id; Rows.Add(u); return Task.FromResult(u.Id);
    }
    public Task RegisterFailureAsync(long id, int attempts, DateTime? lockedUntilUtc, CancellationToken ct = default)
    {
        var u = Rows.First(r => r.Id == id); u.FailedAttempts = attempts; u.LockedUntil = lockedUntilUtc;
        return Task.CompletedTask;
    }
    public Task ResetFailuresAsync(long id, CancellationToken ct = default) => RegisterFailureAsync(id, 0, null, ct);
}

sealed class FakeSessions : ISessionRepository
{
    private readonly Dictionary<string, (long User, DateTime Exp)> _s = [];
    public Task CreateAsync(long userId, byte[] h, DateTime exp, CancellationToken ct = default)
    { _s[Convert.ToHexString(h)] = (userId, exp); return Task.CompletedTask; }
    public Task<long?> FindUserIdAsync(byte[] h, DateTime now, CancellationToken ct = default) =>
        Task.FromResult(_s.TryGetValue(Convert.ToHexString(h), out var v) && v.Exp > now ? (long?)v.User : null);
    public Task DeleteAsync(byte[] h, CancellationToken ct = default)
    { _s.Remove(Convert.ToHexString(h)); return Task.CompletedTask; }
}

sealed class FakeAudit : IAuditLog
{
    public readonly List<(long? User, string Event, string? Detail)> Events = [];
    public Task AppendAsync(long? userId, string eventName, string? detail = null)
    { Events.Add((userId, eventName, detail)); return Task.CompletedTask; }
    public Task<bool> VerifyChainAsync() => Task.FromResult(true);
}

public class AuthServiceTests
{
    private const string Pw = "Str0ng!Passw0rd";
    private readonly TestClock _clock = new();
    private readonly FakeUsers _users = new();
    private readonly FakeAudit _audit = new();
    private readonly AuthService _auth;

    public AuthServiceTests() => _auth = new AuthService(_users, new FakeSessions(), _audit, _clock);

    private Task<AuthResult> Register(string u = "rama_mousa", string e = "rama@example.com") =>
        _auth.RegisterAsync(u, e, Pw, Pw);

    [Fact]
    public async Task Register_then_login_succeeds_and_stores_no_plaintext()
    {
        Assert.True((await Register()).Success);
        var row = _users.Rows.Single();
        Assert.NotEqual(System.Text.Encoding.UTF8.GetBytes(Pw), row.PasswordHash);
        Assert.StartsWith("argon2id", row.KdfParams);
        Assert.NotEmpty(row.PasswordSalt);

        var login = await _auth.LoginAsync("Rama_Mousa", Pw);   // case-insensitive username
        Assert.True(login.Success);
        Assert.NotNull(login.SessionToken);
    }

    [Fact]
    public async Task Login_works_with_email_too()
    {
        await Register();
        Assert.True((await _auth.LoginAsync("rama@example.com", Pw)).Success);
    }

    [Fact]
    public async Task Unknown_user_and_wrong_password_return_identical_error()
    {
        await Register();
        var wrongPw = await _auth.LoginAsync("rama_mousa", "Wrong!Passw0rd1");
        var noUser = await _auth.LoginAsync("nobody", "Wrong!Passw0rd1");
        Assert.False(wrongPw.Success);
        Assert.Equal(wrongPw.Error, noUser.Error);
    }

    [Fact]
    public async Task Account_locks_after_five_failures_even_with_correct_password()
    {
        await Register();
        for (int i = 0; i < AuthService.MaxFailedAttempts; i++)
            await _auth.LoginAsync("rama_mousa", "Wrong!Passw0rd1");

        Assert.False((await _auth.LoginAsync("rama_mousa", Pw)).Success);

        _clock.Now = _clock.Now.AddMinutes(16);   // lock window passes
        Assert.True((await _auth.LoginAsync("rama_mousa", Pw)).Success);
    }

    [Fact]
    public async Task Duplicate_registration_is_rejected()
    {
        await Register();
        Assert.False((await Register()).Success);
    }

    [Fact]
    public async Task Weak_password_is_rejected()
    {
        var r = await _auth.RegisterAsync("someone", "s@example.com", "password", "password");
        Assert.False(r.Success);
        Assert.Empty(_users.Rows);
    }

    [Fact]
    public async Task Session_validates_until_logout()
    {
        await Register();
        var token = (await _auth.LoginAsync("rama_mousa", Pw)).SessionToken!;
        Assert.NotNull(await _auth.ValidateSessionAsync(token));
        await _auth.LogoutAsync(token);
        Assert.Null(await _auth.ValidateSessionAsync(token));
    }

    [Fact]
    public async Task Audit_never_records_the_attempted_login_name()
    {
        await _auth.LoginAsync("secret-typed-here", "Wrong!Passw0rd1");
        Assert.DoesNotContain(_audit.Events, e => (e.Detail ?? "").Contains("secret-typed-here"));
    }
}
